package com.example.mobileapplicationdevelopmentassignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btn;
    EditText principal_text;
    EditText interest_text;
    EditText amort_text;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.button);
        principal_text = findViewById(R.id.principle_input);
        interest_text = findViewById(R.id.interest_input);
        amort_text = findViewById(R.id.amortization_input);
        btn.setOnClickListener(new View.OnClickListener(){


            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, Activity2.class);
                Double EMI = Calculate(view);
                String emi_texc = "Your monthly payment will be:" + Double.toString(EMI);
                i.putExtra("Value",emi_texc);
                startActivity(i);
                finish();
            }
        });


    }

    public Double Calculate(View view){
        String ints = interest_text.getText().toString();
        Double inti = Double.parseDouble(ints);
        String principle_string = principal_text.getText().toString();
        Double principle_double = Double.parseDouble(principle_string);
        String amo_string = amort_text.getText().toString();
        Double amo_double = Double.parseDouble(amo_string);


        Double interestdec = inti* 0.01;
        Double EMI = ((principle_double+(principle_double*amo_double*interestdec))/(amo_double*12));


        return EMI;





    }
}